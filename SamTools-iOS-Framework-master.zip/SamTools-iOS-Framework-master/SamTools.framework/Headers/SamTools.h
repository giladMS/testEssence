//
//  SamTools.h
//  SamTools
//
//  Created by Roy on 20/06/2016.
//  Copyright © 2016 sam. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SamTools.
FOUNDATION_EXPORT double SamToolsVersionNumber;

//! Project version string for SamTools.
FOUNDATION_EXPORT const unsigned char SamToolsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SamTools/PublicHeader.h>


