
# SamTools-iOS-Framework
The Official SamTools Swift SDK for integrating with SAM.
## System Requirments
- iOS 9.0+
- macOS 10.10+
- Xcode 8+

## SDK distribution
You will be able to integrate the SamTools Swift SDK into your project using one of several methods.

### CocoaPods
Yet to come
### Carthage
Yet to come
### Manually add Framework

Finally, you can also integrate the SamTools Swift SDK into your project manually.

## Get started
You are now ready to work with the SDK. :muscle:

Start by creating a reference to the `SamTools.SamServer` instance that you will use to make your API calls.

```
    let samServer = SamTools.SamServer.shared
```
The next thing you want to do is to add yoursef as a listener for `SamServer` using `addListener`

```
    samServer.addListener(self, withID: self.description)
```

You will use this listener to response to the `SamServerDelegate` calls: 
```
public protocol SamServerDelegate {
    
    func connection(state: SamState, error: SamError?)
    func onDeviceConnected(device: Device?, error: SamError?)
    func onDeviceDisconnected(mac: String?, error: SamError?)
    func onDeviceChanged(device: Device?, error: SamError?)
    func onBandwidthDataArrived(data: [BandwidthEntry]?, error: SamError?)
}
```
For now, implement the `connection` call, and leave the others with empty implementation:
```
    func connection(state: SamState, error: SamError?)
    {
        switch state {
        case .close:
          // Update UI
        case .open:
         samServer.getSamID() { [weak self] samID, error in
                if let samID = samID {
                    self?.samServer.registerWithoutDetails(samID: samID){ [weak self] success, mobileID, error in
                        if success == true {
                            // Get pincode from the user
                            self?.samServer.register(phone: "", pincode: pincode { [weak self] success, error in
                              if success == true {
                                self?.startDoStuffWithSAM()
                               } else 
                               {
                                  self?.handleWrongPincode()
                               }
                              }
                               self?.mobileID = mobileID
                              } else {
                                 // Handle failure
                             }
                    }
                } else {
                    // Handle failure, looks like SAM Agent is not installed
                }
            }
        case .authenticated:
         // Start using the SDK!
          startDoStuffWithSAM()
        case .wrongPwd:
          // Update UI
        }
    }
    func onDeviceConnected(device: Device?, error: SamError?){}
    func onDeviceDisconnected(mac: String?, error: SamError?){}
    func onDeviceChanged(device: Device?, error: SamError?){}
    func onBandwidthDataArrived(data: [BandwidthEntry]?, error: SamError?){}
```
Note: When the socket is connected, and the connection state is `.open`, that is your trigger to call `getSamID()` which will give you the Sam ID of Sam agent installed on the router. With this Sam ID you now call `registerWithoutDetails(samID:)` in order to send the authentication SMS to the user. With the PIN code you can now complete the authentication by calling `register(phone:pincode:)` with the PIN code from the user.

You are now ready to connect to the SAM Agent, using `connect()`
```
    samServer.connect()
```
Congrats! You are now connected to SAM and can start exploring your network. :tada:

* Make sure your iPhone is connected to a router with SAM installed

You may start by getting all the different zones with:
```
    public func getAllZones(completion: (([String]?, SamError?)->())?)
```
You can then get the decices for more using:

```
    public func getAllDevices(completion: (([Device]?, SamError?)->())?)
```

Other methods are available as well:
```
    public var state: SamState { get }
```

```
    public func removeListener(_ withID: String)
```

```
    public func disconnect()
```
```
    public func register(phone: String, pincode: String, completion: ((Bool?, SamError?)->())?)
```
```
    public func getSamVersion(completion: ((String?, SamError?)->())?)
```
```
    public func getSamID(completion: ((String?, SamError?)->())?)
```
```
    public func getInternetState(completion: ((Router?, SamError?)->())?)
```
```
    public func restartRouter(completion: ((Bool?, SamError?)->())?)
```

```
    public func changeDeviceZone(device: Device, zone: String, completion: ((Bool?, SamError?)->())?)
```
```
    public func changeDeviceDisplayName(device: Device, newDisplayName: String, completion: ((Bool?, SamError?)->())?)
```
```
    public func changeDeviceParentalControl(device: Device, isOn: Bool, completion: ((Bool?, SamError?)->())?)
```
```
    public func changeDevicePolicy(toState: ProtectionState, mac: String, completion: ((Bool?, SamError?)->())?)
```
```
    public func changeDeviceTrack(device: Device, track: TrackingState, completion: ((Bool?, SamError?)->())?)
```
```
    public func setPFRules(device: Device, rules: [PortForwardingRule], completion: (([PortForwardingRule]?, SamError?)->())?)
```
```
    public func deletePFRules(device: Device, rules: [PortForwardingRule], completion: (([PortForwardingRule]?, SamError?)->())?)
```
```
    public func queryPFRules(device: Device, completion: ((String?, [PortForwardingRule]?, SamError?)->())?)
```
```
    public func getWifiPassword(completion: ((WifiData?, SamError?)->())?)
```
```
    public func setWifiPassword(newPassword: String?, encryptionType: WifiEncryptionType, completion: ((WifiData?, SamError?)->())?)
```
```
    public func getWifiSSID(completion: (((ssid24: String?, ssid5: String?)?, SamError?)->())?)
```
```
    public func setWifiSSID(ssid24G: String, ssid5G: String, completion: ((Bool?, SamError?)->())?)
```
```
    public func getPPPUser(completion: ((String?, SamError?)->())?)
```
```
    public func setPPPUser(username: String, completion: ((Bool?, SamError?)->())?)
```
```
    public func getPPPPassword(completion: ((String?, SamError?)->())?)
```
```
    public func setPPPPassword(password: String, completion: ((Bool?, SamError?)->())?)
```
```
    public func getWifiChannel(completion: ((WifiChannel?, SamError?)->())?)
```
```
    public func setWifiChannel(channels: WifiChannel, completion: ((Bool?, SamError?)->())?)
```
```
    internal func connection(state: SamState, error: SamError?)
```
```
    internal func onDeviceConnected(device: Device?, error: SamError?)
```
```
    internal func onDeviceDisconnected(mac: String?, error: SamError?)
```
```
    internal func onDeviceChanged(device: Device?, error: SamError?)
```
```
    internal func onBandwidthDataArrived(data: [BandwidthEntry]?, error: SamError?)
```
```
    public func migratePush(samID: String, deviceID: String, completion: ((String?, SamError?) -> ())?)
```
```
    public func registerForPushNotifications(_ token: String, completion: ((String?, SamError?) -> ())?)
```
```
    public func updateTokenForDeviceID(mobileID: String, samID: String, token: String, completion: ((String?, SamError?) -> ())?)
```
```
    public func verifyCustomerAndRequestSMS(_ samID: String, phone: String, serial: String, completion: ((Bool?, String?, SamError?) -> ())?)
```
```
    public func registerWithoutDetails(samID: String, completion: ((Bool?, String?, SamError?) -> ())?)
```
```
    public func getMobile(samID: String, completion: ((String?, SamError?) -> ())?)
```
```
    public func verifySerialForSamID(serial: String, samID: String, completion: ((Bool?, SamError?) -> ())?)
```
```
    public func verifyCertificateForSamID(samID: String, certificate: SecCertificate, completion: ((Bool?, SamError?) -> ())?)
```
```
    public func checkAppVersionSupport(version: String, completion: ((String?, Bool?, SamError?) -> ())?)
```
```
    public func getAllFeeds(completion: ((String?, Bool?, SamError?) -> ())?)
```
```
    public func deleteFeeds(feeds: [Feed], completion: ((Bool?, SamError?)->())?)
```
```
    public func getTrackStatus(completion: ((Bool?, [Int: TrackingState]?, SamError?)->())?)
```
```
    public func setTrackState(device: Device, state: TrackingState, completion: ((Bool?, SamError?)->())?)
```
```
    public func getPushState(completion: ((Bool?, PushState?, SamError?)->())?)
```
```
    public func setPushState(on: Bool, completion: ((Bool?, SamError?)->())?)
```
```
    open func getDeviceIPAddress() -> String?
```
```
public enum SamLoginState {

    case success

    case wrongPassword

    case wrongSamID
}
```
